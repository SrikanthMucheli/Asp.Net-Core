﻿using Microsoft.AspNetCore.Mvc;

namespace ModelClassBinding.Model
{
    public class Book
    {
        public int ?BookId { get; set; }
        public string ?Name { get; set; }
    }
}
