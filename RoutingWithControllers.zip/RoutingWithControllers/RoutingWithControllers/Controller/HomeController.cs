﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RoutingWithControllers.Controller
{
    public class HomeController
    {
        // GET: HomeController

        [Route("/Home")]
        public string Index()
        {
            return "Welecome to the routing with Controllers";
        }
    }
}
