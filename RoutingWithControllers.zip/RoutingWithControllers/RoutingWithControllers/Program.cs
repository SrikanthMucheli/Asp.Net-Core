using RoutingWithControllers.Controller;

var builder = WebApplication.CreateBuilder(args);

// builder.Services.AddTransient<HomeController>();    antother way as below

builder.Services.AddControllers();

var app = builder.Build();

//app.UseRouting();       // another way as below

// app.UseEndpoints(endpoint => { endpoint.MapControllers(); });

app.MapControllers();

app.Run();
