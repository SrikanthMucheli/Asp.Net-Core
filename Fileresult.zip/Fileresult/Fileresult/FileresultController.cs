﻿using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Reflection.Metadata;

namespace Fileresult
{
    public class FileresultController : Controller
    {
        [Route("/")]
        /*public VirtualFileResult Index()
        {
            here  first parametes is path of the file and second is type of the file
            return new VirtualFileResult("Samples/CSharp 7.0 LabBook.pdf", "appliction/pdf");
        } */
       /* public PhysicalFileResult Index()
        {
            here first parametes is path of the file and second is type of the file
            return new PhysicalFileResult("C:\\Users\\smucheli\\Documents\\Learning\\M3-.NetCore\\.NET Core\\M1\\C#\\PDF\\CSharp 7-ClassBook-Lesson 01.pdf", "appliction/pdf");
            or
            return new PhysicalFile("C:\\Users\\smucheli\\Documents\\Learning\\M3-.NetCore\\.NET Core\\M1\\C#\\PDF\\CSharp 7-ClassBook-Lesson 01.pdf", "appliction/pdf");

        }  */

        public FileContentResult index()
        {
            byte[] b = System.IO.File.ReadAllBytes(@"C:\\Users\\smucheli\\Documents\\Learning\\M3-.NetCore\\.NET Core\\M1\\C#\\PDF\\CSharp 7-ClassBook-Lesson 01.pdf");

            // return new FileContentResult(b,"application/pdf");  //or
            return File(b, "application/pdf")
        }
    }
}
