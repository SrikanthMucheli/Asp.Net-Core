﻿using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Reflection.Metadata;

namespace Fileresult
{
    public class FileresultController : Controller
    {
        [Route("/")]

        // for all types of return result we can use    IActionResult
        public IActionResult index()
        {
            byte[] b = System.IO.File.ReadAllBytes(@"C:\\Users\\smucheli\\Documents\\Learning\\M3-.NetCore\\.NET Core\\M1\\C#\\PDF\\CSharp 7-ClassBook-Lesson 01.pdf");

            // return new FileContentResult(b,"application/pdf");  //or
            return File(b, "application/pdf");
        }
    }
}
