﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using JsonRslt;

namespace RoutingWithControllers.Controller
{
    public class HomeController : ControllerBase
    {

        [Route("/")]
        public JsonResult Can()
        {
            Emp a = new Emp() { id = 10, Name = "Srikanth" };

            // here application/json automatically set the json
            //return new JsonResult(a,"application/json");    another way as below
            return Json(a);
        }
    }
}
