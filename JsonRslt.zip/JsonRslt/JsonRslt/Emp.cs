﻿namespace JsonRslt
{
    public class Emp
    {
        public string Name { get; set; }
        public int id { get; set; }
    }
}
