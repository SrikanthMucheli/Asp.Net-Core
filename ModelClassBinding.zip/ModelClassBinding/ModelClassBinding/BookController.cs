﻿using ModelClassBinding.Model;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace QueryStringAndRouteParameterBinding
{
    public class BookController : Controller
    {
        // Model Class Binding
        [Route("/Books/{Id}/{Author}")]
        public IActionResult BooK(Book book)
        {
            if(book.BookId.HasValue)
            {
                   return View(book);
            }

            return View();
        }
    }
}
