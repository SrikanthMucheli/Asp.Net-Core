﻿using Microsoft.AspNetCore.Mvc;

namespace ModelClassBinding.Model
{
    public class Book
    {
        [FromQuery]
        public int ?BookId { get; set; }

        [FromRoute]
        public string ?Name { get; set; }
    }
}
