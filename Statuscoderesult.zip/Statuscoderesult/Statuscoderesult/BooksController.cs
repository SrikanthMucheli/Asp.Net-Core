﻿using Microsoft.AspNetCore.Mvc;

namespace Statuscoderesult
{
    public class BooksController : Controller
    {
        [Route("/Books")]
        public IActionResult index()
        {
           if(!Request.Query.ContainsKey("Bookid"))
           {
                // Response.StatusCode = 400;    badrequest
                return new BadRequestResult();
           }

            var bookId = Convert.ToInt32(Request.Query["Bookid"]);

           if (bookId < 1 || bookId >1000)
            {
                // not found
                return new NotFoundResult();
            }
            if (!Convert.ToBoolean(Request.Query["IsLogged"]))
            {
                retun new Unauthorized("");
            }
           return View();
        }
    }
}
