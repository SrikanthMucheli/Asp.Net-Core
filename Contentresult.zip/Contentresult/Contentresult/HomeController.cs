﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RoutingWithControllers.Controller
{
    public class HomeController : ControllerBase
    {
        // GET: HomeController

        [Route("/Home")]

        //Content result will return any type of values
        public ContentResult Index()
        {
            return new ContentResult
            {
                //Content = "Welcome to content result topic",
                //ContentType = "text/plain",
                Content = "<h1>Welcome to content result topic</h1>",
                ContentType = "text/HTML",
            };
        }

        [Route("/")]
        public ContentResult Can()
        {
            return Content("<h1>Welcome to content result topic</h1>", "text/HTML"); 
        }
    }
}
