﻿
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace QueryStringAndRouteParameterBinding
{
    public class BookController : Controller
    {
        // Model Binding
        [Route("/Books")]
        public IActionResult BooK(int? bookId, string author)
        {
            return Content($"Book id is {bookId} Autor is {author}");
        }

        // Model Binding
        [Route("/Books/{BookId}/{Autor}")]
        public IActionResult BooKs([FromRoute]int? bookId, [FromQuery] string author)
        {
            return Content($"Book id is {bookId} Autor is {author}");
        }
    }
}
