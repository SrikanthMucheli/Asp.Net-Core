﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace ModelClassBinding.Model
{
    public class Book
    {
        // Custom validation msg
        // [Required (ErrorMessage ="Bookid mandantory")]  or
        [Required (ErrorMessage = "{0} Bookid mandantor")]
        [Display(Name = "BookId")]   // here {0} replaced with Name
        public int ?BookId { get; set; }

        // noraml validation
        [Required]
        public string ?Name { get; set; }
    }
}
