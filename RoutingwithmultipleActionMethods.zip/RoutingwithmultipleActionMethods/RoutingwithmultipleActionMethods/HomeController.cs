﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RoutingWithControllers.Controller
{
    [Controller]
    public class Home
    {
        // GET: HomeController

        [Route("Home")]
        [Route("/")]
        public string Homee()
        {
            return "Welecome to the  Home routing with Controllers";
        }

        [Route("About")]
        public string About()
        {
            return "Welecome to the About routing with Controllers";
        }

        [Route("Info")]
        public string Info()
        {
            return "Welecome to the  Inforouting with Controllers";
        }
    }
}
