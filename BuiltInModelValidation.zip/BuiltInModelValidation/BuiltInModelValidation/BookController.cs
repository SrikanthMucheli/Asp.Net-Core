﻿using ModelClassBinding.Model;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace QueryStringAndRouteParameterBinding
{
    public class BookController : Controller
    {
        // Model Validation
        [Route("/Books/{Id}/{Author}")]
        public IActionResult BooK(Book book)
        {
            // is valid
            if(!ModelState.IsValid)
            {
               return BadRequest();
            }

            // values  & errors
            if (!ModelState.IsValid)
            {
                List<string> errors = new List<string>();
                foreach(var values in ModelState.Values)
                { 
                    foreach (var error in values.Errors)
                    {
                          errors.Add(error.ErrorMessage);
                    }
                }

                string result = string.Join("\n ", errors);
                return BadRequest(result);
            }
            return View();
        }
    }
}
