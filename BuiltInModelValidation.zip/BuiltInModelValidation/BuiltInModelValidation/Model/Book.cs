﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace ModelClassBinding.Model
{
    public class Book
    {
        // Custom validation msg
        // [Required (ErrorMessage ="Bookid mandantory")]  or
        [Required (ErrorMessage = "{0} Bookid mandantor")]
        [Display(Name = "BookId")]   // here {0} replaced with Name
        public int ?BookId { get; set; }

        // noraml validation
        [Required]
        // [StringLength(50)]  or
        [StringLength(50 ,MinimumLength = 10, ErrorMessage ="Must be in range")]
        [RegularExpression("^[a-zA-Z ]$")]
        public string ?Name { get; set; }


        [Range(0, 10)]
        public decimal? price { get; set; }


        [EmailAddress]
        public string email { get; set; }

        public string feild1 { get; set; }

        [Compare("feild1")]
        public string  feild2 { get; set; }

    }
}
