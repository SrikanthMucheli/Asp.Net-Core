﻿using Microsoft.AspNetCore.Mvc;

namespace RedirectToAction
{
    public class BooksController : Controller
    {
        [Route("/Books")]
        public IActionResult index()
        {
            // return new RedirectToAction ("A", "Books", null);
            return new RedirectToActionResult("A", "Books", null);
        }

        [Route("/Category/Books")]
        public IActionResult A()
        {
            return View();
        }
    }
}
